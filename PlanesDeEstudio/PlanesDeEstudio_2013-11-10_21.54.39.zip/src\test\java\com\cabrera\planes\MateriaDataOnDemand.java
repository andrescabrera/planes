package com.cabrera.planes;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Materia.class)
public class MateriaDataOnDemand {
}
