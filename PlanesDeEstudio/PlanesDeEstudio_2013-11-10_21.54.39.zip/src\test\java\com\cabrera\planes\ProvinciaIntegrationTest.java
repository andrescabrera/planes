package com.cabrera.planes;
import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Provincia.class)
public class ProvinciaIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
