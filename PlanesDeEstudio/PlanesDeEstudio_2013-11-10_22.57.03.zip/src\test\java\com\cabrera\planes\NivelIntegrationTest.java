package com.cabrera.planes;
import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Nivel.class)
public class NivelIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
