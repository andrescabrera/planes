package com.cabrera.planes;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Carrera.class)
public class CarreraDataOnDemand {
}
