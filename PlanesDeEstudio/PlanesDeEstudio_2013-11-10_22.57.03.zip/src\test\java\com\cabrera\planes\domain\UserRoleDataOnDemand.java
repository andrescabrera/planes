package com.cabrera.planes.domain;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = UserRole.class)
public class UserRoleDataOnDemand {
}
