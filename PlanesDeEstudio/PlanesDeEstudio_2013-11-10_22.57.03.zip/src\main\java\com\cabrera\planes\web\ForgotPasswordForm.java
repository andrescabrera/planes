/**
 * 
 */
package com.cabrera.planes.web;

/**
 * @author rohit
 * 
 */
public class ForgotPasswordForm {

	private String emailAddress;

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @param emailAddress
	 *            the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

}
