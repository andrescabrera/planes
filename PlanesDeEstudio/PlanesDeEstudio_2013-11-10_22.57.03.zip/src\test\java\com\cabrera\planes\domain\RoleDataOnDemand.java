package com.cabrera.planes.domain;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Role.class)
public class RoleDataOnDemand {
}
