package com.cabrera.planes;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = EstadoMateria.class)
public class EstadoMateriaDataOnDemand {
}
