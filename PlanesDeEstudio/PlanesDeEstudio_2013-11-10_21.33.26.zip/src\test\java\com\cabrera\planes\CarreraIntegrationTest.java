package com.cabrera.planes;
import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Carrera.class)
public class CarreraIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
