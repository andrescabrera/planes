package com.cabrera.planes;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Estudiante.class)
public class EstudianteDataOnDemand {
}
