package com.cabrera.planes;
import org.springframework.roo.addon.javabean.RooJavaBean;
import org.springframework.roo.addon.jpa.activerecord.RooJpaActiveRecord;
import org.springframework.roo.addon.tostring.RooToString;
import javax.validation.constraints.Size;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.ManyToMany;

@RooJavaBean
@RooToString
@RooJpaActiveRecord
public class Materia {

    @Size(min = 1, max = 64)
    private String codigo;

    @Size(min = 1, max = 64)
    private String nombre;

    /**
     * Las materias correlativas a esta materia.
     */
    @ManyToMany(cascade = CascadeType.ALL)
    private Set<Materia> correlativas = new HashSet<Materia>();

    @ManyToMany(cascade = CascadeType.ALL)
    private Set<PlanDeEstudio> planes = new HashSet<PlanDeEstudio>();
}
