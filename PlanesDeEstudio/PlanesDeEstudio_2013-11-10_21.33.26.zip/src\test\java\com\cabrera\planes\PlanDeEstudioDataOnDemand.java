package com.cabrera.planes;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = PlanDeEstudio.class)
public class PlanDeEstudioDataOnDemand {
}
