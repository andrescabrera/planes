package com.cabrera.planes;
import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Universidad.class)
public class UniversidadIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
